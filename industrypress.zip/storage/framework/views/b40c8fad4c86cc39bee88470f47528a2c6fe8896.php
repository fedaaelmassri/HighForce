
<div class="contener" style="text-align: justify;" dir="ltr">

<br>
<hr>


	<h2 style="text-align: center;"> Subject: <?php echo e($Subject); ?> </h2>
	
	<h3> <strong>  Dear </strong> ,</h3>
	
    <?php echo $content; ?>


    	
	<hr>
	
</div><?php /**PATH F:\larvel\industrypress\resources\views/emails/system-mail.blade.php ENDPATH**/ ?>