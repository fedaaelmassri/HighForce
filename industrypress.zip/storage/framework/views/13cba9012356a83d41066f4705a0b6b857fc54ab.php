<?php $__env->startSection('style'); ?>
<style>

.image{
    margin-left:24rem;

}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<!--begin::Portlet-->
<div class="kt-portlet">
    <div class="kt-portlet__head">
        <div class="kt-portlet__head-label">
            <h3 class="kt-portlet__head-title">
                Edit Category
            </h3>
        </div>
    </div>

    <!--begin::Form-->
    <form method="post" action="<?php echo e(route('admin.category.update',[ 'id' => $Category->id ])); ?>" enctype="multipart/form-data" class="kt-form kt-form--label-right">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
        <div class="kt-portlet__body">
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Name:</label>
                <div class="col-lg-4 col-md-9 col-sm-12">
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo e($Category->name); ?>" placeholder="Enter Category name">
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Description:</label>
                <div class="col-lg-4 col-md-9 col-sm-12">
                    <textarea class="form-control" id="description" name="description" placeholder="Enter a description" rows="8"><?php echo e($Category->description); ?></textarea>
                    <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                </div>
            </div>

            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Image Browser</label>
                <div class=" custom-file col-lg-4 col-md-9 col-sm-12">
                    <input type="file" class="custom-file-input" id="image" name="image">
                    <label class="custom-file-label text-left" for="customFile">Choose image</label>
                    <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                </div>
            </div>
            <div class="row form-group ">

                        <img class="image " src="<?php echo e(asset('storage/' . $Category->image)); ?>" height="100"  >
                    </div>

            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Main Category</label>
                <div class="col-lg-4 col-md-9 col-sm-12">
                    <select class="custom-select form-control" id="category_id" name="category_id">
                        <option selected="">Select Category</option>
                        <?php if($Category->parent_id==0): ?>
                        <option value="0" selected="selected"> Main Category </option>
                        <?php $__currentLoopData = App\Categories::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id == $Category->id): ?>
                          <?php continue; ?>
                          <?php endif; ?>

                            <option value="<?php echo e($item->id); ?>"> <?php echo e($item-> name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                          <option value="0"  > Main Category </option>
                        <?php $__currentLoopData = App\Categories::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id == $Category->id): ?>
                          <?php continue; ?>
                          <?php endif; ?>
                            <option value="<?php echo e($item->id); ?>"   <?php echo e(old('category_id', $Category->parent_id) == $item->id ? ' selected' : ''); ?>> <?php echo e($item-> name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="kt-portlet__foot">
            <div class="kt-form__actions">
                <div class="row">
                    <div class="col-lg-8 ml-lg-auto">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="<?php echo e(route('admin.category')); ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--end::Form-->
</div>

<!--end::Portlet-->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\larvel\industrypress\resources\views/backend/Categories/update.blade.php ENDPATH**/ ?>