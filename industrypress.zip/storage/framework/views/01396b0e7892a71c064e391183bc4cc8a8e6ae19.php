<?php $__env->startSection('content'); ?>

  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5"  data-bg-img="<?php echo e(asset('storage/' . $new->image )); ?>">
      <div class="container pt-100 pb-50">
        <!-- Section Content -->
        <div class="section-content pt-100">
          <div class="row">
            <div class="col-md-12">
              <h3 class="title text-white"><?php echo e($new->name); ?></h3>
              <ul class="breadcrumb white">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active"><?php echo e($new->name); ?></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Blog -->
    <section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row">
          <div class="col-md-9">
            <div class="blog-posts single-post">
              <article class="post clearfix mb-0">
                <div class="entry-header">
                  <div class="post-thumb thumb"> <img src="<?php echo e(asset('storage/' . $new->image )); ?>" alt="" class="img-responsive img-fullwidth"> </div>
                </div>
                <div class="entry-content">
                  <div class="entry-meta media no-bg no-border mt-15 pb-20">
                    <div class="entry-date media-left text-center flip bg-theme-colored pt-5 pr-15 pb-5 pl-15">
                      <ul>
                        <li class="font-16 text-white font-weight-600"><?php echo e($new->created_at->format('d')); ?></li>
                        <li class="font-12 text-white text-uppercase"><?php echo e($new->created_at->format('m')); ?></li>
                      </ul>
                    </div>
                    <div class="media-body pl-15">
                      <div class="event-content pull-left flip">
                        <h4 class="entry-title text-white text-uppercase m-0"><a href="#"><?php echo e($new->name); ?></a></h4>
                        </div>
                    </div>
                  </div>
                  <p class="mb-15">
                  <?php echo e($new->description); ?>

                   </p>

                </div>
              </article>

            </div>
          </div>
          <div class="col-md-3">
            <div class="sidebar sidebar-left mt-sm-30">

              <div class="widget">
                <h5 class="widget-title line-bottom">Latest News</h5>
                <div class="latest-posts">
                <?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestnews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <article class="post media-post clearfix pb-0 mb-10">
                  <a class="post-thumb" href="<?php echo e(route('new-details' , [ 'id' => $latestnews->id ])); ?>"><img src="<?php echo e(asset('storage/' . $latestnews->image )); ?>" width="75" height="75" alt=""></a>
                    <div class="post-right">
                      <h5 class="post-title mt-0"><a href="<?php echo e(route('new-details' , [ 'id' => $latestnews->id ])); ?>"><?php echo e($latestnews->name); ?></a></h5>
                      <p><?php echo e(substr($latestnews->description,0,strpos($latestnews->description, ' ', 30))); ?> ...</p>
                    </div>
                  </article>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>

              <div class="widget">
                <h5 class="widget-title line-bottom">Archives</h5>
                <ul class="list-divider list-border list check">
                <?php $__currentLoopData = $archivenews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivenews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><a href="<?php echo e(route('new-details' , [ 'id' => $archivenews->id ])); ?>"><?php echo e($archivenews->name); ?></a></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\larvel\industrypress\resources\views/frontend/new-details.blade.php ENDPATH**/ ?>