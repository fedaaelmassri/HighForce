<?php $__env->startSection('style'); ?>
<style>

.image{
    margin-left:24rem;

}
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!--begin::Portlet-->
<div class="kt-portlet">
    <div class="kt-portlet__head">
        <div class="kt-portlet__head-label">
            <h3 class="kt-portlet__head-title">
               UPDATE Abouts
            </h3>
        </div>
    </div>

    <!--begin::Form-->
    <form method="post" action="<?php echo e(route('admin.aboutUs.update', [ 'id' => $about->id ])); ?>"  class="kt-form kt-form--label-right">
                      <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
        <div class="kt-portlet__body">
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Title:</label>
                <div class="col-lg-6 col-md-9 col-sm-12">
                    <input type="text" id="name" name="name" class="form-control" placeholder="Enter brand name" value="<?php echo e($about->name); ?>" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">

                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Description:</label>
                <div class="col-lg-6 col-md-9 col-sm-12">
                    <textarea class="form-control" id="description" name="description" placeholder="Enter a description" rows="8"><?php echo e($about->description); ?></textarea>
                    <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>


            <div class="kt-portlet__foot">
                <div class="kt-form__actions">
                    <div class="row">
                        <div class="col-lg-8 ml-lg-auto">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <!-- <button type="submit" class="btn btn-secondary">Cancel</button> -->
                        </div>
                    </div>
                </div>
            </div>

    </form>
</div>

<!--end::Portlet-->







<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\larvel\industrypress\resources\views/backend/aboutUs/update.blade.php ENDPATH**/ ?>