<?php $__env->startSection('content'); ?>


<!--begin::Portlet-->
<div class="kt-portlet">
    <div class="kt-portlet__head">
        <div class="kt-portlet__head-label">
            <h3 class="kt-portlet__head-title">
                Settings
            </h3>
        </div>
    </div>

    <!--begin::Form-->
    <form method="post" action="<?php echo e(route('admin.setting.update')); ?>" class="kt-form kt-form--label-right">
        <?php echo csrf_field(); ?>


        <div class="kt-portlet__body">
            <?php $__currentLoopData = $Settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $settings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12"><?php echo e($settings->constant); ?> :</label>
                <div class="col-lg-6 col-md-9 col-sm-12">
                    <input type="text" class="form-control <?php if ($errors->has('<?php echo e($settings->constant); ?>')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('<?php echo e($settings->constant); ?>'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($settings->constant); ?>" value="<?php echo e(old($settings->constant,$settings->value)); ?>" autofocus>

                    <?php if ($errors->has('<?php echo e($settings->constant); ?>')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('<?php echo e($settings->constant); ?>'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">From Time :</label>
                <div class="col-lg-6 col-md-9 col-sm-12 timepicker">
                    <!-- <input type="text" class="form-control  <?php if ($errors->has('time')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('time'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="time" value="<?php echo e(old('time',$settings->value)); ?>" autofocus> -->
                    <input  id="kt_timepicker_1" class="form-control <?php if ($errors->has('<?php echo e($time->constant); ?>')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('<?php echo e($time->constant); ?>'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="<?php echo e($time->constant); ?>" value="<?php echo e(old('$time->constant',$time->value)); ?>" autofocusid="example-time-input">
                    <?php if ($errors->has('$time->constant')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('$time->constant'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">To Time :</label>
                <div class="col-lg-6 col-md-9 col-sm-12 ">
                    <!-- <input type="text" class="form-control  <?php if ($errors->has('time')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('time'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="time" value="<?php echo e(old('time',$settings->value)); ?>" autofocus> -->
                    <input  id="kt_timepicker_1" class="form-control <?php if ($errors->has('<?php echo e($to_time->constant); ?>')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('<?php echo e($to_time->constant); ?>'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="<?php echo e($to_time->constant); ?>" value="<?php echo e(old('$to_time->constant',$to_time->value)); ?>" autofocusid="example-time-input">
                    <?php if ($errors->has('$to_time->constant')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('$to_time->constant'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">From Today</label>
                <div class="col-lg-6 col-md-9 col-sm-12">
                    <select class="custom-select form-control" name='from_today'>
                        <option selected="">Open this select menu</option>

                        <option <?php if($from_today->value == 'Saturday'): ?>selected <?php endif; ?> value="Saturday">Saturday</option>
                        <option <?php if($from_today->value == 'Sunday'): ?>selected <?php endif; ?> value="Sunday">Sunday</option>
                        <option <?php if($from_today->value == 'Monday'): ?>selected <?php endif; ?> value="Monday">Monday</option>
                        <option <?php if($from_today->value == 'Tuesday'): ?>selected <?php endif; ?> value="Tuesday">Tuesday</option>
                        <option <?php if($from_today->value == 'Wednesday'): ?>selected <?php endif; ?> value="Wednesday">Wednesday</option>
                        <option <?php if($from_today->value == 'Thursday'): ?>selected <?php endif; ?> value="Thursday">Thursday</option>
                        <option <?php if($from_today->value == 'Friday'): ?>selected <?php endif; ?> value="Friday">Friday</option>
                    </select>
                </div>

            </div>

            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">To Today</label>
                <div class="col-lg-6 col-md-9 col-sm-12">
                    <select class="custom-select form-control" name='to_today'>
                        <option selected="">Open this select menu</option>

                        <option <?php if($to_today->value == 'Saturday'): ?>selected <?php endif; ?> value="Saturday">Saturday</option>
                        <option <?php if($to_today->value == 'Sunday'): ?>selected <?php endif; ?> value="Sunday">Sunday</option>
                        <option <?php if($to_today->value == 'Monday'): ?>selected <?php endif; ?> value="Monday">Monday</option>
                        <option <?php if($to_today->value == 'Tuesday'): ?>selected <?php endif; ?> value="Tuesday">Tuesday</option>
                        <option <?php if($to_today->value == 'Wednesday'): ?>selected <?php endif; ?> value="Wednesday">Wednesday</option>
                        <option <?php if($to_today->value == 'Thursday'): ?>selected <?php endif; ?> value="Thursday">Thursday</option>
                        <option <?php if($to_today->value == 'Friday'): ?>selected <?php endif; ?> value="Friday">Friday</option>
                    </select>
                </div>

            </div>
            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Email:</label>
                <div class="col-lg-6 col-md-9 col-sm-12">
                    <input type="email" class="form-control <?php if ($errors->has('$email->constant')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('$email->constant'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="<?php echo e($email->constant); ?>" value="<?php echo e($email->value); ?>" autofocus>

                    <?php if ($errors->has('<?php echo e($email->constant); ?>')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('<?php echo e($email->constant); ?>'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>


            <div class="form-group row">
                <label class="col-form-label col-lg-3 col-sm-12">Single File Upload</label>
                <div class="col-lg-4 col-md-9 col-sm-12">
                    <div class="kt-dropzone dropzone" action="inc/api/dropzone/upload.php" id="m-dropzone-one">
                        <div class="kt-dropzone__msg dz-message needsclick">
                            <h3 class="kt-dropzone__msg-title">Drop files here or click to upload.</h3>
                            <span class="kt-dropzone__msg-desc">This is just a demo dropzone. Selected files are <strong>not</strong> actually uploaded.</span>
                        </div>
                    </div>
                </div>
            </div>


            <div class="kt-portlet__foot">
                <div class="kt-form__actions">
                    <div class="row">
                        <div class="col-lg-8 ml-lg-auto">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <!-- <button type="submit" class="btn btn-secondary">Cancel</button> -->
                        </div>
                    </div>
                </div>
            </div>

    </form>
</div>

<!--end::Portlet-->







<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/app/custom/general/crud/forms/widgets/bootstrap-timepicker.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\larvel\industrypress\resources\views/backend/Settings/setting.blade.php ENDPATH**/ ?>