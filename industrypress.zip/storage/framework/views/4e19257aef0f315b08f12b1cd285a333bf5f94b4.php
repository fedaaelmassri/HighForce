<?php $__env->startSection('content'); ?>
  <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header bg-gray-darkgray ">
      <div class="container pt-10 pb-10">
        <!-- Section Content -->
        <div class="section-content">
        <div class="row">
        <div class="col-md-12">
              <h3 class="title text-theme-colored">E-Catalog</h3>
              <ul class="breadcrumb white">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">E-Catalog</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>



<section>
  <div class="container mt-30 mb-30 pt-30 pb-30" style="margin-left: 185px;">
     <div class="row" >
         <?php $__currentLoopData = $ecatalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecatalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-xs-6 col-md-3" style="margin-left: -74px;margin-top: 10px;">
                  <div  style="position: relative;  ">
              <img alt="..." src="<?php echo e(asset('storage/' . $ecatalog->image )); ?>"  width="200" height="230">
               <a class="btn btn-colored btn-flat btn-theme-colored  pb-10"   href="<?php echo e(route('download', [$ecatalog->id])); ?>" style="width:200px; margin-top:3px;">Download</a>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
    </div>
</section>
</div>
<!-- end main-content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\larvel\industrypress\resources\views/frontend/ecatalog.blade.php ENDPATH**/ ?>