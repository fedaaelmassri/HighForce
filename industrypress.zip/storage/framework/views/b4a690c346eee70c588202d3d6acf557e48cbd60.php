
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-6 col-md-4 col-lg-4 mb-30">
                <div class="product pb-0">
                  <div class="product-thumb">
                  <img alt="" src="<?php echo e(asset('storage/'.$products->image)); ?>"width="320" heigt="360" class="img-responsive img-fullwidth">

                  </div>
                  <div class="product-details text-center bg-lighter pt-15 pb-10">
                    <a href="#"><h5 class="product-title mt-0"><?php echo e($products->name); ?></h5></a>
                  </div>
                </div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-12">
                <nav>
                <?php echo e(\App\Products::paginate(10)); ?>


                </nav>
              </div>
<?php /**PATH F:\larvel\industrypress\resources\views/frontend/productsByBraCat.blade.php ENDPATH**/ ?>