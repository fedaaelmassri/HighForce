
<div class="contener" style="text-align: justify;" dir="ltr">

<br>
<hr>


	<h2 style="text-align: center;"> Subject: {{$Subject}} </h2>
	
	<h3> <strong>  Dear </strong> ,</h3>
	
    {!! $content !!}

    	
	<hr>
	
</div>