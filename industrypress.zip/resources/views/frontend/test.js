   //   var x=0;
                                        // var _id,_id2,_id3;
                                        // var getcat,getcat2,getcat_1;
                                        // var catid = {{$categories->id }};
                                        // {{route('product_details' , [ 'id' => valu.id ])}}
                                        //        var url='{{URL::to('/admin/products')}}';

                                        // var caturl= '{{URL::to('/product_details')}}';
                                            // $(document).ready(function() {
                    //                               $.ajax({
                    //   type:'GET',
                    //   dataType:'json',
                    //   url:'{{URL::to('/getSupCat')}}',
                    //   success:function(data){
                    //    $.each(data.categories,function(index,valu){
                    //        if(value.parent_id==0   ){
                    //       	$('#catlist').append(
                    //                 //   '  <li class=" "><a href=" ">'+ value.name+'</a></li>'
                    //                   ' <option  value="'+valu.name+'"  >'+valu.name+' </option> '

                    //                     );
                    //         _id=valu.id;
                    //        // get();
                    //         }

                    //     })

                    //   }

                    //                         });


                                //  });
